import os
import unittest
from server_services import ServerServices

class TestSum(unittest.TestCase):
    """
    This module is used for the unit testing and it does testing for the folder_creation and read_file
    """
    def test_folder_creation(self):
        """
        Test for folder_creation
        """
        client = ServerServices(os.getcwd(), os.getcwd(), 'reshmi')
        input_data = [
            'reshmi','reshmi'
        ]
        expected_value = [
            'failed to create folder',
            'failed to create folder'
        ]
        result = []
        for inputval in input_data:
            result.append(client.create_folder(inputval))
        self.assertListEqual(result, expected_value)


    def test_read_file(self):
        """
        Test to read_file
        """
        way = os.path.join(os.getcwd(), 'reshmi')
        client = ServerServices(os.getcwd(), way, 'reshmi')
        input_data = [
            ['ok.txt'],
            ['asdf.txt'],
            ['set.txt']
        ]
        expected_value = [
            'file doesnot exist',
            'file doesnot exist',
            'file doesnot exist'
        ]
        result = []
        for inputval in input_data:
            result.append(client.file_read(inputval[0]))
        self.assertListEqual(result, expected_value)

    def test_write_file(self, file_name, new_name, input_id):
        
        self.filename = new_name
        self.file_name = f"{file_name}\\"
        self.inp = input_id
        self.is_write = False
        try:
                self.path_mod = os.path.join(self.root_path, self.file_name)
                self.path = os.path.join(self.path_mod, self.filename)
                with open(self.path, 'w') as is_write:
                    is_write.write(self.inp)
                    self.is_write = True
        except Exception as exp:
                print(exp)
        finally:
                    return self.is_write
     
    def test_change_folder_path(self, old_name):
        """
        To change a folder path we specify which folder to be changed
        It takes one arguments i.e,; the folder name.
        """
        self.old_name = old_name
        self.curr = False
        os.chdir(self.root_path)
        try:
            os.chdir(old_name)
            self.curr = True
        except Exception:
            pass
        finally:
            return self.curr   

if __name__ == '__main__':
    unittest.main()
